### Hexlet tests and linter status:
[![Actions Status](https://github.com/D1lex1/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/D1lex1/python-project-49/actions)


### Codeclimate Maintainability:
[![Maintainability](https://api.codeclimate.com/v1/badges/d5a163aac0d0bebd2e90/maintainability)](https://codeclimate.com/github/D1lex1/python-project-49/maintainability)

